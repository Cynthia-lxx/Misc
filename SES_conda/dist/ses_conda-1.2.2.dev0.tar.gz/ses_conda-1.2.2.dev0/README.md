**SES Conda**: A simple concept of SES `Conda` language.  

*Update log*:  
1.2.2-dev 2025/03/13 (Experimental) `expo` function included. 
1.1.3 2025/01/16 Fixed syntax errors.
1.1.2 2024/10/2 Fixed some of the `export()` functions. Added a `rels` index in the `database()` function for relationship storage.  
1.1.1 2024/10/2 Added a function(`rels.parse()`) for parsing relationships.  
1.0.3 2024/10/2 Fixed the `database.load`  from  `json()` function. No need to convert anymore.  
